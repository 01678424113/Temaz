<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="assets/production/images/favicon.ico" type="image/ico"/>

    <title> Happyness Work Admin</title>

    
    <base href="/">

    <?php echo $__env->make('layouts.partial.style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
          rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <?php echo $__env->make('layouts.partial.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <br/>

                <!-- sidebar menu -->
            <?php echo $__env->make('layouts.partial.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /sidebar menu -->
            </div>
        </div>

        <!-- top navigation -->
    <?php echo $__env->make('layouts.partial.top-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /page content -->

        <!-- footer content -->
    <?php echo $__env->make('layouts.partial.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /footer content -->
    </div>
</div>

<?php echo $__env->make('layouts.partial.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- iCheck -->
<link rel="stylesheet" href="/assets/vendors/iCheck/skins/square/blue.css">
<script src="/assets/vendors/iCheck/icheck.min.js"></script>
<script type="text/javascript" language="JavaScript" src="/js/functions.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<!-- ckeditor -->
<script src="https://cdn.ckeditor.com/4.5.11/full/ckeditor.js"></script>
<?php echo $__env->yieldContent('script'); ?>

<script>
    $(function () {
        $(".datepicker").datepicker().attr('autocomplete', 'off');
    });
    if ($('#input_editor').length) {
        CKEDITOR.replace('input_editor');
    }
</script>
</body>
</html>
