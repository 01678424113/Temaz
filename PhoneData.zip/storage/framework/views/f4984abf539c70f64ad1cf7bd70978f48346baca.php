<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="<?php echo e($id ?? ''); ?>">
        <?php echo e($label ?? ''); ?>

        <?php if($is_required ?? ''): ?> <span class="required">*</span> <?php endif; ?>
    </label>
    <div class="col-md-9 col-sm-9 col-xs-12">
        <input class="knob"
               data-width="<?php echo e($width ?? 100); ?>"
               data-height="<?php echo e($height ?? 120); ?>"
               data-min="<?php echo e($min ?? 0); ?>"
               data-displayPrevious=true
               data-fgColor="<?php echo e($color ?? '#26B99A'); ?>"
               <?php if($readonly ?? ''): ?> readonly <?php endif; ?>
               <?php if($is_required ?? ''): ?> required <?php endif; ?>
               id="<?php echo e($id ?? ''); ?>"
               name="<?php echo e($name ?? ''); ?>"
               value="<?php echo e($value ?? 1); ?>" />
    </div>
</div>

<?php $__env->startPush('script_default'); ?>
    <!-- jQuery Knob -->
    <script src="assets/vendors/jquery-knob/dist/jquery.knob.min.js"></script>
<?php $__env->stopPush(); ?>
