

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Cập nhật công ty</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <br/>
                                    <form action="<?php echo e(route('companies.update', $model->id)); ?>" method="post"
                                          class="form-horizontal form-label-left">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                    'label' => 'Tên công ty',
                                                    'name' => 'company_name',
                                                    'is_required' => true,
                                                    'value' => $model->company_name
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                    'label' => 'Alias',
                                                    'name' => 'alias',
                                                    'is_required' => true,
                                                    'value' => $model->alias
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                'label' => 'BucketAwsS3',
                                                'name'=>'bucket_awss3',
                                                'value' => $model->bucket_awss3
                                            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Chọn gói (user):
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <?php
                                                        if (in_array($model->packet_id, $listIdPacket)) {
                                                            $readonly = true;
                                                        } else {
                                                            $readonly = false;
                                                        }
                                                        ?>
                                                        <?php echo Form::select('packet_id', $packets, $model->packet_id, ['class' => 'form-control select2','readonly'=>$readonly]); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Ngày bắt đầu <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <input type="text"
                                                               name="time_start"
                                                               <?php echo e((!empty($companyPacket) ? 'readonly' : '')); ?>

                                                               value="<?php echo e((!empty($companyPacket) ? $companyPacket->time_start : '')); ?>"
                                                               class="form-control datepicker">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Ngày kết thúc <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <input type="text"
                                                               name="time_end"
                                                               <?php echo e((!empty($companyPacket) ? 'readonly' : '')); ?>

                                                               value="<?php echo e((!empty($companyPacket) ? $companyPacket->time_end : '')); ?>"
                                                               class="form-control datepicker">
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                   'label' => 'Tên',
                                                   'name' => 'name',
                                                   'is_required' => true,
                                                   'readonly'=>true,
                                                   'value' => (!empty($admin)) ? $admin->name : ''
                                               ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                  'label' => 'Email',
                                                  'name' => 'email',
                                                  'is_required' => true,
                                                  'readonly'=>true,
                                                  'value' => (!empty($admin)) ? $admin->email : ''
                                              ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Secret token <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <input type="text" required
                                                               name="secret_token"
                                                               value="<?php echo e(($model->secret_token)); ?>"
                                                               class="form-control">
                                                    </div>
                                                </div>

                                                <?php echo $__env->make('layouts.components.form-html.switch-checked', [
                                                                                                'label' => 'Trạng thái',
                                                                                                'name' => 'status',
                                                                                                'is_checked' => $model->status
                                                                                            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                                <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-primary">Quay
                                                    lại</a>
                                                <button type="submit" name="btnSubmit" class="btn btn-success">Lưu thay
                                                    đổi
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>