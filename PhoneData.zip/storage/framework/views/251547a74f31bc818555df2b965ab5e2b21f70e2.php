<div class="navbar nav_title" style="border: 0;">
    <a href="<?php echo e(route('home')); ?>" class="site_title"><i class="fa fa-paw"></i> <span>System HRM!</span></a>
</div>

<div class="clearfix"></div>

<!-- menu profile quick info -->
<div class="profile clearfix">
    <div class="profile_pic">
        <img src="assets/production/images/img.jpg" alt="..." class="img-circle profile_img">
    </div>
    <div class="profile_info">
        <span>Xin chào,</span>
        <h2><?php echo e(Auth::user()->name); ?></h2>
        <span><?php echo e(number_format(Auth::user()->amount)); ?> VND</span>
    </div>
</div>
<!-- /menu profile quick info -->
