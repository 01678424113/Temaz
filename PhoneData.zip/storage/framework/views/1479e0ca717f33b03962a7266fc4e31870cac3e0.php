<div class="">
    <label>
        <input type="checkbox"
               <?php if($readonly ?? ''): ?> readonly <?php endif; ?>
               class=""
               name="<?php echo e($name ?? ''); ?>"
               <?php if($is_checked ?? ''): ?> checked <?php endif; ?>/>
    </label>
</div>
