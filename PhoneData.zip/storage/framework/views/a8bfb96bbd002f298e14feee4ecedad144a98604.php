<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Danh sách số đã Import </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <form action="<?php echo e(route('category.doAddPhoneToCategory')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback" style="padding: 5px;">
                        <select name="category_id"
                                class="form-control select2"
                                id="">
                            <?php if(!empty($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <button class="btn btn-info" style="margin-top: 10px;">Cập nhập</button>

                    </div>

                    <div class="x_content">
                        <table id="datatable-buttons" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th style="width: 30px">#</th>
                                <th>Số điện thoại</th>
                                <th>Danh mục</th>
                                <th>Nguồn</th>
                                <th>Thời gian</th>
                                <th>Thời gian import</th>
                                <th>Link</th>
                                <th>Hành động</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(!empty($data)): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="phoneIds[]" value="<?php echo e($value->id); ?>" style="width: 20px;height: 20px;"/>
                                        </td>
                                        <td><?php echo e($value->phone); ?></td>
                                        <td><?php echo e($value->category_name); ?></td>
                                        <td><?php echo e($value->source); ?></td>
                                        <td><?php echo e($value->time); ?></td>
                                        <td><?php echo e($value->created_at); ?></td>
                                        <td><a target="_blank" href="<?php echo e($value->link); ?>">Click</a></td>
                                        <td>
                                            <a href="<?php echo e(route('phone.edit',['id'=>$value->id])); ?>"
                                               class="btn btn-xs btn-info"><i
                                                        class="fa fa-edit"></i></a>
                                            <a href="<?php echo e(route('phone.destroy',['id'=>$value->id])); ?>"
                                               class="btn btn-xs btn-danger"><i
                                                        class="fa fa-times"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>