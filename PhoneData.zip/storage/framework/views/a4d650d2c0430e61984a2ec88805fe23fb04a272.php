<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">
        <?php echo e($label ?? ''); ?>

        <?php if($is_required ?? ''): ?> <span class="required">*</span> <?php endif; ?>
    </label>
    <div class="col-md-9 col-sm-9 col-xs-12">
        <select class="select2_single form-control"
                <?php if($readonly ?? ''): ?> readonly <?php endif; ?>
                <?php if($is_required ?? ''): ?> required <?php endif; ?>
                id="<?php echo e($id ?? ''); ?>"
                name="<?php echo e($name ?? ''); ?>"
                tabindex="-1">
            <option value="">...</option>
            <?php if(!empty($data)): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if(isset($value) && ($value === $key)): ?> selected <?php endif; ?> value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
</div>
