<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Cập nhật tài khoản</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <br/>
                                    <form action="<?php echo e(route('user-admin.update', $model->id)); ?>" method="post"
                                          class="form-horizontal form-label-left">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                    'label' => 'Tên người dùng',
                                                    'name' => 'name',
                                                    'is_required' => true,
                                                    'value' => $model->name
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-email', [
                                                   'label' => 'Email',
                                                   'name' => 'email',
                                                   'is_required' => true,
                                                   'value' => $model->email
                                               ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-password', [
                                                  'label' => 'Mật khẩu mới',
                                                  'name' => 'password',
                                                  'is_required' => false,
                                                  'value' => ''
                                              ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-password', [
                                                    'label' => 'Nhập lại mật khẩu',
                                                    'name' => 'password_confirmation',
                                                    'is_required' => false,
                                                    'value' => ''
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">Số
                                                        tiền</label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <input type="text"
                                                               readonly
                                                               id=""
                                                               name="amount"
                                                               value="<?php echo e(number_format($model->amount)); ?>"
                                                               placeholder=""
                                                               class="form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Chọn vai trò:
                                                    </label>
                                                    <div class=" col-md-3 col-sm-6 col-xs-12">
                                                        <?php echo Form::select('role',$roles, old('role')??$model->getRoleNames(), ['class' => 'form-control select2']); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Trạng thái
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <input type="checkbox" id="" name="status"
                                                               <?php if($model->status ?? ''): ?> checked <?php endif; ?> class=""/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                                <a href="<?php echo e(route('user-admin.index')); ?>" class="btn btn-primary">Quay
                                                    lại</a>
                                                <button type="submit" name="btnSubmit" class="btn btn-success">Lưu thay
                                                    đổi
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>