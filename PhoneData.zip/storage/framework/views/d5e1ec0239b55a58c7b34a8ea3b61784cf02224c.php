

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Danh sách công ty </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table id="datatable-company" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Tên công ty</th>
                            <th>Bí danh</th>
                            <th>Kho chứa Awss3</th>
                            <th>Số tiền</th>
                            <th>Ngày đăng ký thành viên</th>
                            <th>User tối đa</th>
                            <th>Ngày đăng hết hạn</th>
                            <th>Trạng thái</th>
                            <th>Hành động</th>
                        </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#datatable-company').DataTable({
                "order": [[0, "asc"]],
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('companies.index')); ?>",
                "columns": [
                    {"data": "company_name"},
                    {"data": "alias"},
                    {"data": "bucket_awss3"},
                    {"data": "balance", render: $.fn.dataTable.render.number(',', '.', 0, 'VNĐ ')},
                    {"data": "created_at"},
                    {
                        "data": "max_user", render: function (data) {
                            let view = (data === '' || data === null) ? 0 : data;
                            return view;
                        }
                    },
                    {
                        "data": "expired_packet", render: function (data) {
                            let view = (data === '' || data === null) ? 'Đã hết hạn' : data;
                            return view;
                        }
                    },
                    {
                        "data": "status", render: function (data) {

                            let htmlChecked = '<span title="Kích hoạt" class="switchery switchery-default" style="background-color: rgb(38, 185, 154); border-color: rgb(38, 185, 154); box-shadow: rgb(38, 185, 154) 0px 0px 0px 11px inset; transition: border 0.4s, box-shadow 0.4s, background-color 1.2s;"><small style="right: 0px; background-color: rgb(255, 255, 255); transition: background-color 0.4s, left 0.2s;"></small></span>';
                            let htmlUnchecked = '<span title="Không kích hoạt" class="switchery switchery-default" style="box-shadow: rgb(223, 223, 223) 0px 0px 0px 0px inset; border-color: rgb(223, 223, 223); background-color: rgb(255, 255, 255); transition: border 0.4s, box-shadow 0.4s;"><small style="left: 0px; transition: background-color 0.4s, left 0.2s;"></small></span>';

                            let view = '<div class="js-switch">' + ((data === 1) ? htmlChecked : htmlUnchecked) + '</div>';

                            return view;
                        }
                    }
                ],
                "columnDefs": [{
                    "targets": 8, // đây là cột thứ n tổng cột trong datatable
                    "data": "description",
                    render: function (data, type, row) {

                        let urlRenewal = "<?php echo e(route('packet-manager.renewal', 'company_id')); ?>";
                        urlRenewal = urlRenewal.replace('company_id', row['id']);

                        let urlEdit = "<?php echo e(route('companies.edit', 'id')); ?>";
                        urlEdit = urlEdit.replace('id', row['id']);

                        let urlDelete = "<?php echo e(route('companies.destroy', 'id')); ?>";
                        urlDelete = urlDelete.replace('id', row['id']);

                        let urlChangePacket = "<?php echo e(route('packet-manager.changePacket', 'company_id')); ?>";
                        urlChangePacket = urlChangePacket.replace('company_id', row['id']);
                        if (type === "display") {
                            let btnRenewal = "<a title='Gia hạn gói' href=\"" + urlRenewal + "\" class=\"btn btn-xs btn-info\"><i\n" +
                                "                                            class=\"fa fa-plus\"></i></a>";

                            let btnEdit = "<a title='Sửa' href=\"" + urlEdit + "\" class=\"btn btn-xs btn-info\"><i\n" +
                                "                                            class=\"fa fa-pencil\"></i></a>";
                            let btnDelete = "<a title='Xóa' href=\"" + urlDelete + "\" class=\"btn btn-xs btn-danger\"><i\n" +
                                "                                            class=\"fa fa-times\"></i></a>";
                            let btnChangePacket = "<a title='Thay đổi gói' target='_blank' href=\"" + urlChangePacket + "\" class=\"btn btn-xs btn-success\"><i\n" +
                                "                                            class=\"fa fa-vine\"></i></a>";

                            return btnChangePacket + btnRenewal + btnEdit + btnDelete
                        }
                        return "";
                    }
                }]
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .switchery {
            height: 20px !important;
            width: 40px !important;
        }

        .switchery > small {
            height: 20px !important;
            width: 25px !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>