<?php $__env->startSection('content'); ?>
    <div class="login">
        <div class="login_wrapper">
            <div class="animate form login_form">
                <section class="login_content">
                    <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Đăng nhập')); ?>">
                        <?php echo csrf_field(); ?>
                        <h1>Đăng nhập</h1>
                        <div>
                            <input id="email" type="email"
                                   placeholder="Enter your email"
                                   class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                   name="email" value="<?php echo e(old('email')); ?>" required>
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div>
                            <input id="password" type="password"
                                   placeholder="Enter your password"
                                   class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                   name="password" required>
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="hidden">
                            <input type="checkbox"
                                   name="remember"
                                   checked <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Remember Me')); ?>

                        </div>
                        <div class="clearfix"></div>
                        <div>
                            <button type="submit" class="btn btn-info">
                                <?php echo e(__('Đăng nhập')); ?>

                            </button>
                            <a class="reset_pass" href="<?php echo e(route('password.request')); ?>">Quên mật khẩu?</a>
                        </div>

                        <div class="clearfix"></div>

                        <div class="separator">
                            <div>
                                <h1><i class="fa fa-paw"></i> <?php echo e(env('NAME_SYSTEM')); ?>!</h1>
                                <p>©2018 by Louis</p>
                            </div>
                        </div>
                    </form>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>