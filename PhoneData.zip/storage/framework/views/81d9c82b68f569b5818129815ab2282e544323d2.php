

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Danh sách giao dịch </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Page 1</a>
                                </li>
                                <li><a href="#">Page 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>STT</th>
                            <th>Mã giao dịch</th>
                            <th>Tên công ty</th>
                            <th>Loại giao dịch</th>
                            <th>Số tiền</th>
                            <th>Nội dung</th>
                            <th>Thời gian giao dịch</th>
                            <th>Trạng thái</th>
                            <th>Hành động</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(!empty($data)): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($value->transaction_id); ?></td>
                                    <td><?php echo e($value->company_name); ?></td>
                                    <td>
                                        <?php if($value->type == \App\Models\Transaction::$TYPE_PLUS): ?>
                                            <label class="label label-success">Cộng tiền</label>
                                        <?php elseif($value->type == \App\Models\Transaction::$TYPE_MINUS): ?>
                                            <label class="label label-danger">Trừ tiền</label>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(number_format($value->amount)); ?></td>
                                    <td><?php echo e($value->note); ?></td>
                                    <td><?php echo e(date('H:i:s d/m/Y', strtotime($value->created_at))); ?></td>
                                    <td>
                                        <?php if($value->status == \App\Models\Transaction::$STATUS_SUCCESS): ?>
                                            <label class="label label-success">Thành công</label>
                                        <?php elseif($value->status == \App\Models\Transaction::$STATUS_PENDING): ?>
                                            <label class="label label-warning">Đang xử lý</label>
                                        <?php elseif($value->status == \App\Models\Transaction::$STATUS_FAILURE): ?>
                                            <label class="label label-danger">Thất bại</label>
                                        <?php elseif($value->status == \App\Models\Transaction::$STATUS_CANCEL): ?>
                                            <label class="label label-default">Hủy bỏ</label>
                                        <?php elseif($value->status == \App\Models\Transaction::$STATUS_INIT): ?>
                                            <label class="label label-default">Mới tạo</label>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('transaction-manager.show',['id'=>$value->id])); ?>" class="btn btn-xs btn-success"><i
                                                    class="fa fa-eye"></i></a>
                                        <a href="<?php echo e(route('transaction-manager.edit',['id'=>$value->id])); ?>" class="btn btn-xs btn-info"><i
                                                    class="fa fa-pencil"></i></a>
                                        <a href="<?php echo e(route('transaction-manager.destroy',['id'=>$value->id])); ?>" class="btn btn-xs btn-danger"><i
                                                    class="fa fa-times"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>