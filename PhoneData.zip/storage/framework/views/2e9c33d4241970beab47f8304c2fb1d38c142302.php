

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Cộng tiền</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <br/>
                                    <form action="<?php echo e(route('companies.doMoney')); ?>" method="post"
                                          class="form-horizontal form-label-left">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">Công
                                                        ty <span> *</span></label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <?php echo Form::select('company_id', $companies, old('company_id'), ['class' => 'form-control select2']); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">Loại
                                                        giao dịch <span> *</span></label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <select name="type" id="" class="form-control" required>
                                                            <option value="<?php echo e(\App\Models\Transaction::$TYPE_PLUS); ?>">Cộng
                                                                tiền
                                                            </option>
                                                            <option value="<?php echo e(\App\Models\Transaction::$TYPE_MINUS); ?>">Trừ
                                                                tiền
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">Trạng
                                                        thái <span> *</span></label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <select name="status" id="" class="form-control" required>
                                                            <option
                                                                value="<?php echo e(\App\Models\Transaction::$STATUS_SUCCESS); ?>">
                                                                Thành công
                                                            </option>
                                                            <option
                                                                value="<?php echo e(\App\Models\Transaction::$STATUS_PENDING); ?>">
                                                                Đang xử lý
                                                            </option>
                                                            <option
                                                                value="<?php echo e(\App\Models\Transaction::$STATUS_FAILURE); ?>">
                                                                Thất bại
                                                            </option>
                                                            <option value="<?php echo e(\App\Models\Transaction::$STATUS_CANCEL); ?>">
                                                                Hủy bỏ
                                                            </option>
                                                            <option selected
                                                                    value="<?php echo e(\App\Models\Transaction::$STATUS_INIT); ?>">
                                                                Mới tạo
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-8 col-sm-6 col-xs-12">
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Số tiền <span> *</span>
                                                    </label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <input type="number" min="0" required class="form-control"
                                                               name="balance"
                                                               placeholder="">
                                                        <span class="fa fa-money form-control-feedback right"
                                                              aria-hidden="true"></span>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">Lý
                                                        do</label>
                                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                                        <textarea name="note" id="" cols="30" rows="2"
                                                                  class="form-control"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                                <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-primary">Quay
                                                    lại</a>
                                                <button type="submit" name="btnSubmit" class="btn btn-success">Lưu thay
                                                    đổi
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>