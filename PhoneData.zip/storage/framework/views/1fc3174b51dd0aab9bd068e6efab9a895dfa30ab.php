<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="<?php echo e($id ?? ''); ?>">
        <?php echo e($label ?? ''); ?>

        <?php if($is_required ?? ''): ?> <span class="required">*</span> <?php endif; ?>
    </label>
    <div class="col-md-9 col-sm-9 col-xs-12">
        <input type="text"
               <?php if($readonly ?? ''): ?> readonly <?php endif; ?>
               <?php if($is_required ?? ''): ?> required <?php endif; ?>
               id="<?php echo e($id ?? ''); ?>"
               name="<?php echo e($name ?? ''); ?>"
               value="<?php echo e($value ?? ''); ?>"
               placeholder="<?php echo e($placeholder ?? ''); ?>"
               class="form-control">
    </div>
</div>
