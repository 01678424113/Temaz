
<?php $__env->startSection('content'); ?>
    <style>
        .dataTables_filter {
            width: auto !important;
        }
    </style>
    <div class="row top_tiles">
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="tile-stats" style="background: #66BAB7;">
                <div class="icon"><i class="fa fa-caret-square-o-right"></i></div>
                <h3>REGISTER</h3>
                <div class="count">220</div>
                <p>+ 50%</p>
            </div>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="tile-stats" style="background: #4183D7 ">
                <div class="icon"><i class="fa fa-comments-o"></i></div>
                <h3>REGISTER</h3>
                <div class="count">220</div>
                <p>+ 50%</p>
            </div>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="tile-stats" style="background: #00AA90">
                <div class="icon"><i class="fa fa-sort-amount-desc"></i></div>
                <h3>REGISTER</h3>
                <div class="count">220</div>
                <p>+ 50%</p>
            </div>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="tile-stats" style="background: #F4B350;">
                <div class="icon"><i class="fa fa-sort-amount-desc"></i></div>
                <h3>REGISTER</h3>
                <div class="count">220</div>
                <p>+ 50%</p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Biểu đồ giao dịch
                        <small>Update</small>
                    </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="row" style="border-bottom: 1px solid #E0E0E0; padding-bottom: 5px; margin-bottom: 5px;">
                        <div class="col-md-12">
                            <div id="transactionChart" style="height: 400px; min-width: 310px"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 20px">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Thông báo gia hạn Services</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table id="datatable-buttons" class="table table-hover">
                        <thead>
                        <tr>
                            <th>STT</th>
                            <th>Công ty</th>
                            <th>Dịch vụ</th>
                            <th>Ngày còn lại</th>
                            <th>Hành động</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $reportExpires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportExpire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($i); ?></th>
                                <td><?php echo e($reportExpire->company_name); ?></td>
                                <td><?php echo e($reportExpire->service_name); ?></td>
                                <td><?php echo e(($reportExpire->expired < 0) ? 0 : $reportExpire->expired); ?></td>
                                <td><a href="<?php echo e(route('services-company.index',['id'=>$reportExpire->company_id])); ?>"
                                       class="btn btn-xs btn-warning"><i
                                                class="fa fa-pencil"></i></a></td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 20px">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Thông báo gia hạn gói</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table id="datatable-buttons" class="table table-hover">
                        <thead>
                        <tr>
                            <th>STT</th>
                            <th>Công ty</th>
                            <th>User tối đa</th>
                            <th>Ngày còn lại</th>
                            <th>Hành động</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $reportExpiredPackets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportExpiredPacket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($i); ?></th>
                                <td><?php echo e($reportExpiredPacket->company_name); ?></td>
                                <td><?php echo e($reportExpiredPacket->max_user); ?></td>
                                <td><?php echo e(($reportExpiredPacket->expired < 0) ? 0 : $reportExpiredPacket->expired); ?></td>
                                <td><a href="<?php echo e(route('companies.money',['id'=>$reportExpiredPacket->id])); ?>"
                                       class="btn btn-xs btn-warning"><i
                                                class="fa fa-pencil"></i></a></td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Biểu đồ số đăng ký
                        <small>Update</small>
                    </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="row" style="border-bottom: 1px solid #E0E0E0; padding-bottom: 5px; margin-bottom: 5px;">
                        <div class="col-md-12">
                            <div id="companyRegistersChart" style="height: 400px; min-width: 310px"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('script_default'); ?>
            <script src="https://code.highcharts.com/stock/highstock.js"></script>
            <script src="https://code.highcharts.com/stock/modules/exporting.js"></script>
            <script src="https://code.highcharts.com/stock/modules/export-data.js"></script>
            <script>
                Highcharts.stockChart('companyRegistersChart', {
                    rangeSelector: {
                        selected: 1
                    },
                    series: [{
                        name: 'Số công ty',
                        data: <?php echo e(json_encode($dataCompanyRegisters)); ?>,
                        tooltip: {
                            valueDecimals: 2
                        }
                    }]
                });
                //Bieu do giao dich
                var seriesOptions = [],
                    seriesCounter = 0,
                    names = ['Nạp tiền', 'Trừ tiền'];

                /**
                 * Create the chart when all data is loaded
                 * @returns  {undefined}
                 */
                function createChart() {

                    Highcharts.stockChart('transactionChart', {

                        rangeSelector: {
                            selected: 4
                        },

                        yAxis: {
                            labels: {
                                formatter: function () {
                                    return this.value;
                                }
                            },
                            plotLines: [{
                                value: 0,
                                width: 2,
                                color: 'silver'
                            }]
                        },

                        plotOptions: {
                            series: {

                                showInNavigator: true
                            }
                        },

                        tooltip: {
                            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> <br/>',
                            valueDecimals: 2,
                            split: true
                        },

                        series: seriesOptions
                    });
                }

                seriesOptions[0] = {
                    name: names[0],
                    data: <?php echo e(json_encode($dataTransactionsPlus)); ?>

                };
                seriesOptions[1] = {
                    name: names[1],
                    data: <?php echo e(json_encode($dataTransactionsMinus)); ?>

                };
                createChart();
            </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>