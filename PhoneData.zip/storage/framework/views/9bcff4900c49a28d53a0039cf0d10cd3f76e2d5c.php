<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Sửa vai trò</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <br/>
                                    <form action="<?php echo e(route('role.update',['id'=>$role->id])); ?>" method="post"
                                          class="form-horizontal form-label-left">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                    'label' => 'Tên vai trò',
                                                    'name' => 'name',
                                                    'is_required' => true,
                                                    'value' =>$role->name,
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <div class="form-group">
                                                    <label class="col-md-3 col-sm-3 col-xs-12 control-label">Chọn
                                                        quyền</label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <div class="row">
                                                            <?php if(!empty($permissions)): ?>
                                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="col-md-4">
                                                                        <div class="checkbox">
                                                                            <label class="">
                                                                                <div class="icheckbox_flat-green checked"
                                                                                     style="position: relative;"><input
                                                                                            name="permissions[]"
                                                                                            type="checkbox" class="flat"
                                                                                            <?php echo e(($role->hasPermissionTo($permission->name)) ? 'checked' : ''); ?> value="<?php echo e($permission->id); ?>"
                                                                                            style="position: absolute; opacity: 0;">
                                                                                    <ins class="iCheck-helper"
                                                                                         style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins>
                                                                                </div> <?php echo e($permission->name); ?>

                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                                <a href="<?php echo e(route('role.index')); ?>" class="btn btn-primary">Quay
                                                    lại</a>
                                                <button type="submit" name="btnSubmit" class="btn btn-success">Lưu thay
                                                    đổi
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>