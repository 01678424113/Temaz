<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>HRM ADMIN</h3>
        <ul class="nav side-menu">
            <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Trang chủ </a></li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-bank"></i> Quản lý công ty <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('companies.index')); ?>">Danh sách công ty</a></li>
                    <li><a href="<?php echo e(route('companies.create')); ?>">Tạo mới công ty</a></li>
                    <li><a href="<?php echo e(route('companies.money')); ?>">Cộng tiền</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-user"></i> Quản lý tài khoản <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('user-admin.index')); ?>">Danh sách tài khoản</a></li>
                    <li><a href="<?php echo e(route('user-admin.create')); ?>">Tạo mới tài khoản</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-star"></i> Quản lý dịch vụ <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('services.index')); ?>">Danh sách dịch vụ</a></li>
                    <li><a href="<?php echo e(route('services.create')); ?>">Tạo mới dịch vụ</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-group"></i> Phân quyền admin<span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('role.index')); ?>">Vai trò</a></li>
                    <li><a href="<?php echo e(route('permission.index')); ?>">Quyền</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-group"></i> Phân quyền cloud<span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('RoleCloud_index')); ?>">Quyền chung</a></li>
                    <li><a href="<?php echo e(route('RoleCloud_add')); ?>">Thêm quyền chung</a></li>

                    <li><a href="<?php echo e(route('ActionGroup_index')); ?>">Nhóm Quyền</a></li>
                    <li><a href="<?php echo e(route('ActionGroup_add')); ?>">Thêm nhóm Quyền</a></li>

                    <li><a href="<?php echo e(route('permission-cloud.index')); ?>">Action</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-sitemap"></i> Quản lý menu <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('menus.index')); ?>">Danh sách menu</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-cc"></i> Quản lý giao dịch <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('transaction-manager.index')); ?>">Danh sách giao dịch</a></li>
                    <li><a href="<?php echo e(route('transaction-manager.manager')); ?>">Thống kê doanh thu</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-suitcase"></i> Quản lý gói <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('packet-manager.index')); ?>">Danh sách gói</a></li>
                    <li><a href="<?php echo e(route('packet-manager.create')); ?>">Tạo gói mới</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-suitcase"></i> Quản lý Enneagram <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('enneagram-details.index')); ?>">Danh sách</a></li>
                    <li><a href="<?php echo e(route('enneagram-details.create')); ?>">Tạo mới</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="fa fa-suitcase"></i> Quản lý Help <span class="fa fa-chevron-down"></span>
                </a>
                <ul class="nav child_menu">
                    <li><a href="<?php echo e(route('help.index')); ?>">Danh sách</a></li>
                    <li><a href="<?php echo e(route('help.create')); ?>">Tạo mới</a></li>
                </ul>
            </li>
        </ul>
    </div>
</div>
