<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-6 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Thống kê theo bảng</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <table id="datatable-buttons" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>STT</th>
                                            <th>Thời gian</th>
                                            <th>Số tiền</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(!empty($revenues)): ?>
                                            <?php $i = 1; ?>
                                            <?php $__currentLoopData = $revenues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($key); ?></td>
                                                    <td><?php echo e(number_format($value)); ?> VND</td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Biểu đồ doanh thu</h2>
                                    <form action="<?php echo e(route('transaction-manager.manager')); ?>" method="get" id="transaction_manager">
                                        <div class="dataTables_length pull-right">
                                            <select name="time" class="form-control input-sm">
                                                <option <?php echo e((Request::input('time') == 'month') ? 'selected' : ''); ?> value="month" class="form-control">Tháng</option>
                                                <option <?php echo e((Request::input('time') == 'date') ? 'selected' : ''); ?> value="date" class="form-control">Ngày</option>
                                                <option <?php echo e((Request::input('time') == 'year') ? 'selected' : ''); ?> value="year" class="form-control">Năm</option>
                                            </select>
                                        </div>
                                    </form>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i
                                                        class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"
                                               role="button" aria-expanded="false"><i
                                                        class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <canvas id="transactionChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="assets/vendors/Chart.js/dist/Chart.min.js"></script>
    <script>
        $('select[name=time]').change(function () {
            $('#transaction_manager').submit();
        });
        if ($('#transactionChart').length) {
            var ctx = document.getElementById("transactionChart");
            var transactionChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo $month; ?>,
                    datasets: [{
                        label: 'Doanh thu',
                        backgroundColor: "#26B99A",
                        data: <?php echo $money; ?>

                    }]
                },

                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            });

        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>