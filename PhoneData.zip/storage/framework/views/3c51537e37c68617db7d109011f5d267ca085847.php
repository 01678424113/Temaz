

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Danh sách vai trò </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Page 1</a>
                                </li>
                                <li><a href="#">Page 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>STT</th>
                            <th>Tên</th>
                            <th>Giá tiền</th>
                            <th>Ngày hết hạn</th>
                            <th>Trạng thái hoạt động</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(!empty($data)): ?>

                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($i); ?>

                                    </td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <?php echo e(!empty($item->rent_cost) && $item->rent_cost > 0 ? number_format($item->rent_cost) : 'Miễn phí'); ?>

                                    </td>
                                    <td class="text-left"><?php echo e(!empty($item->expired_date) ? date('d-m-Y', strtotime($item->expired_date)) : ''); ?></td>
                                    <td>
                                        <?php if($item->status_service_company == \App\Models\Service::$ACTIVE): ?>
                                            <?php if($item->expired > 30): ?>
                                                <label class="label label-success">Đang hoạt động</label>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('services-company.renewal',['company_id'=>$company_id])); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="service_id" value="<?php echo e($item->id); ?>">
                                                    <select name="month" class="form-control">
                                                        <option value="">Chọn tháng</option>
                                                        <?php for($j = 1; $j < 37; $j++): ?>
                                                            <option value="<?php echo e($j); ?>"><?php echo e($j); ?> tháng</option>
                                                        <?php endfor; ?>
                                                    </select>
                                                    <button class="btn btn-warning btn-sm" style="margin: 0;">Gia hạn</button>
                                                </form>
                                            <?php endif; ?>
                                        <?php elseif($item->status_service == \App\Models\Service::$ACTIVE): ?>
                                            <form action="<?php echo e(route('services-company.register',['company_id'=>$company_id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="service_id" value="<?php echo e($item->id); ?>">
                                                <select name="month" class="form-control">
                                                    <option value="">Chọn tháng</option>
                                                    <?php for($j = 1; $j < 37; $j++): ?>
                                                        <option value="<?php echo e($j); ?>"><?php echo e($j); ?> tháng</option>
                                                    <?php endfor; ?>
                                                </select>
                                                <button class="btn btn-primary btn-sm" style="margin: 0;">Đăng ký</button>
                                            </form>
                                        <?php else: ?>
                                            <label class="label label-default">Tạm khóa</label>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>