

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_content">
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Tạo mới công ty</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <br/>
                                    <form action="<?php echo e(route('companies.store')); ?>" method="post"
                                          class="form-horizontal form-label-left">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                    'label' => 'Tên công ty',
                                                    'name' => 'company_name',
                                                    'is_required' => true
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                    'label' => 'Alias',
                                                    'name' => 'alias',
                                                    'is_required' => true
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Chọn gói (user):
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <?php echo Form::select('packet_id', $packets, old('packet_id'), ['class' => 'form-control select2']); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Ngày bắt đầu <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <input type="text"
                                                               name="time_start"
                                                               class="form-control datepicker">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Ngày kết thúc <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                        <input type="text"
                                                               name="time_end"
                                                               class="form-control datepicker">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                 'label' => 'Tên',
                                                 'name' => 'name',
                                                 'is_required' => true
                                             ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-text', [
                                                  'label' => 'Email',
                                                  'name' => 'email',
                                                  'is_required' => true
                                              ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('layouts.components.form-html.input-password', [
                                                    'label' => 'Mật Khẩu',
                                                    'name' => 'password',
                                                    'is_required' => true,
                                                    'value' => ''
                                                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <div class="form-group">
                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">
                                                        Trạng thái
                                                    </label>
                                                    <div class="col-md-9 col-sm-9 col-xs-12 checkbox-switch">
                                                        <input type="checkbox" name="status" checked class=""/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                                <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-primary"
                                                   type="button">Quay lại</a>
                                                <button type="submit" name="btnSubmit" class="btn btn-success">Tạo công
                                                    ty
                                                </button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>