<label>{{$label}} :</label>
<p style="padding: 5px;">
    <input type="checkbox" name="{{$name}}[]" id="hobby1" value="ski" data-parsley-mincheck="2" required class="flat" /> Skiing
    <br />

    <input type="checkbox" name="{{$name}}[]" id="hobby2" value="run" class="flat" /> Running
    <br />

    <input type="checkbox" name="{{$name}}[]" id="hobby3" value="eat" class="flat" /> Eating
    <br />

    <input type="checkbox" name="{{$name}}[]" id="hobby4" value="sleep" class="flat" /> Sleeping
    <br />
<p>