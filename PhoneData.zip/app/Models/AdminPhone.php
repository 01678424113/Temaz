<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdminPhone extends Model
{
    public $timestamps = false;
}
