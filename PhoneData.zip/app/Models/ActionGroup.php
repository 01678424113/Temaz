<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActionGroup extends Model
{
    public static $ACTIVE = 1;
    public static $INACTIVE = 2;
}
